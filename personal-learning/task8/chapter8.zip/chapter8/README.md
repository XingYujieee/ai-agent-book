# 第 8 章｜模型后训练

我把这章的阅读、实验和还没补齐的条件放在这里。逐项进度以本机实际记录为准，作者的历史活动有单独链接。

- [学习笔记](notes.md)
- [学习心得与课程反馈](reflection-and-feedback.md)
- [实验记录](experiment.md)
- [逐项进度](progress.md)
- [运行结果](results/)

原文：[第 8 章](../../book/chapter8.md)。

本章单独上传：[文件清单](upload-manifest.json) · [下载本章学习档案](chapter8.zip)。
